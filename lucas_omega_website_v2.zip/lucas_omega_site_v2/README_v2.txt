LUCAS OMEGA WEBSITE — VERSION 2 (HYBRID MASCOT / NEON)

RUN
1. Unzip lucas_omega_website_v2.zip
2. Open lucas_omega_site_v2/index.html in Chrome or Edge.
3. Click the floating mascot to open LO-M8 chat.
4. Try "Dẫn mình tham quan" for a guided tour.
5. Click "Visual novel" / "Bắt đầu hành trình" for the story mode.
6. At Developer Access Protocol, enter this JavaScript statement:
   const accessKey = "Lucas" + "Omega";
   Then click "Run code & unlock".

WHAT'S NEW
- Hybrid mascot: guided tour, scripted chat assistant, optional Vietnamese text-to-speech, and visual-novel story mode.
- Neon cyber-tech visual design, responsive layout and animated mascot art.
- Developer challenge accepts a small allow-listed JavaScript declaration without executing arbitrary candidate code.
- Application form preview.

IMPORTANT BEFORE PRODUCTION
- Company profile, role descriptions and culture copy are sample content. Replace with verified company information.
- This is a frontend prototype. The application form does not transmit or store candidate data.
- The access challenge is a playful UX gate, not real security. Enforce any real access control on a server.
- Connect a backend/ATS/email service, add spam protection, retention rules and a privacy notice before collecting real applications.
- Add your official logo, real recruitment email and real contact details.
